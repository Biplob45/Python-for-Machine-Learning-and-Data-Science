name = input("What's your name? ")
age = int(input("How old are you? "))
age_in_dog_years = age * 7

print(f"{name} you are {age_in_dog_years} in dog years. Woof!")