True and True # True
False and True # False
1 == 1 and 2 == 1 # False
"love" == "love" # True
1 == 1 or 2 != 1 # True
True and 1 == 1 # True
False and 0 != 0 # False
True or 1 == 1 # True
"time" == "money" # False
1 != 0 and 2 == 1 # False
"I Can't Believe It's Not Butter!" != "butter" # True
"one" == 1 # False
not (True and False) # True
not (1 == 1 and 0 != 1) # False
not (10 == 1 or 1000 == 1000) # False
not (1 != 10 or 3 == 4) # False
not ("love" == "love" and "time" == "money") # True
1 == 1 and (not ("one" == 1 or 1 == 0)) # True
"chunky" == "bacon" and (not (3 == 4 or 3 == 3)) # False
3 == 3 and (not ("love" == "love" or "Python" == "Fun")) # False