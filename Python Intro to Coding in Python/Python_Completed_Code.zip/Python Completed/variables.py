# Variables are just nicknames
# they're plain, lowercase words
# examples: x, y, banana, phone_a_quail

name = "Mattan Griffel"
orphan_fee = 200
teddy_bear_fee = 121.80

total = orphan_fee + teddy_bear_fee

print(name, "the total will be", total)